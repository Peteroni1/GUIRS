package Roulette;
class Leaderboard {
        private int safeCount;
        private int lossCount;

        public Leaderboard() {
            this.safeCount = 0;
            this.lossCount = 0;
        }

        public void recordSafe() {
            safeCount++;
        }

        public void recordLoss() {
            lossCount++;
        }

        public String getLeaderboard() {
            return "\nLeaderboard:\nSafe Turns: " + safeCount + "\nLosses: " + lossCount + "\n";
        }
    }
