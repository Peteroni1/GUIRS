package Roulette;

import java.awt.EventQueue;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.Font;

// A JFrame to take the user's name
public class NameInput extends JFrame {

    private static final long serialVersionUID = 1L; // Serializable version for JVM
    private JPanel contentPane; // Main panel for layout
    private JTextField textField; // Input field for player's name
    private final JLabel lblNewLabel_3 = new JLabel("");

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        // Start the application on the Event Dispatch Thread (EDT)
        EventQueue.invokeLater(() -> {
            try {
                NameInput frame = new NameInput(); // Create the name input frame
                frame.setVisible(true); // Make it visible
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public NameInput() {
        // Basic frame setup
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Exit on close
        setBounds(100, 100, 450, 400); // Increased height to fit the image
        contentPane = new JPanel(); // Create content panel
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5)); // Add padding

        setContentPane(contentPane); // Set panel as content pane
        contentPane.setLayout(null); // Absolute layout

        // Label for instructions
        JLabel lblNewLabel = new JLabel("Hello, Enter Your Name :D");
        lblNewLabel.setFont(new Font("OCR A Extended", Font.BOLD, 16));
        lblNewLabel.setBounds(65, 59, 317, 52); // Adjusted position
        contentPane.add(lblNewLabel); // Add to panel

        // Text field for name input
        textField = new JTextField();
        textField.setBounds(127, 104, 150, 25); // Adjusted position and size
        contentPane.add(textField); // Add to panel
        textField.setColumns(10); // Set number of columns

        // Button to confirm name entry
        JButton btnNewButton = new JButton("yipieee");
        btnNewButton.addActionListener(e -> {
            String name = textField.getText(); // Get input text
            dispose(); // Close the NameInput frame
            RussianRoulette frame = new RussianRoulette(name); // Open the game window
            frame.setVisible(true); // Make the game visible
        });
        btnNewButton.setBounds(145, 140, 90, 25); // Adjusted position
        contentPane.add(btnNewButton); // Add to panel
        
        JLabel lblNewLabel_1 = new JLabel("");
        lblNewLabel_1.setIcon(new ImageIcon(NameInput.class.getResource("/image/download.jpg")));
        lblNewLabel_1.setBounds(106, 176, 212, 174);
        contentPane.add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("");
        lblNewLabel_2.setIcon(new ImageIcon(NameInput.class.getResource("/image/confetti.png")));
        lblNewLabel_2.setBounds(0, 0, 844, 78);
        contentPane.add(lblNewLabel_2);
        lblNewLabel_3.setIcon(new ImageIcon(NameInput.class.getResource("/image/confetti.png")));
        lblNewLabel_3.setBounds(246, 0, 212, 78);
        contentPane.add(lblNewLabel_3);

        
    }
}
