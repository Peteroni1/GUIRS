package Roulette;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

// Main game class
public class RussianRoulette extends JFrame {

    private static final long serialVersionUID = 1L;
    private static int bulletPosition;
    private static int currentChamber;
    private static boolean gameOn = true;
    private static Leaderboard leaderboard = new Leaderboard();

    // Constructor
    public RussianRoulette(String playerName) {
        setTitle("Russian Roulette");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 600); 
        getContentPane().setLayout(null); 
        setLocationRelativeTo(null);

        
        JPanel panel = new JPanel(null); 
        panel.setBounds(0, 0, 600, 600);
        getContentPane().add(panel);
        panel.setLayout(null);

        // Welcome message
        JLabel welcomeLabel = new JLabel("Welcome to Russian Roulette, " + playerName + "!");
        welcomeLabel.setBounds(50, 20, 500, 30);
        welcomeLabel.setFont(new Font("OCR A Extended", Font.BOLD, 16));
        panel.add(welcomeLabel);

        // Game log area
        JTextArea gameLog = new JTextArea();
        gameLog.setFont(new Font("OCR A Extended", Font.PLAIN, 12));
        gameLog.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(gameLog);
        scrollPane.setBounds(50, 60, 500, 200);
        panel.add(scrollPane);

        // Buttons
        JButton pullTriggerButton = new JButton("Pull Trigger");
        pullTriggerButton.setBounds(151, 280, 120, 30);
        JButton playAgainButton = new JButton("Play Again");
        playAgainButton.setBounds(300, 280, 120, 30);
        playAgainButton.setEnabled(false);
        panel.add(pullTriggerButton);
        panel.add(playAgainButton);

        // Dynamic image label
        JLabel imageLabel = new JLabel();
        imageLabel.setBounds(211, 363, 200, 200);
        panel.add(imageLabel);

        // Random number generator
        Random random = new Random();
        resetGame(random, gameLog, pullTriggerButton, playAgainButton, imageLabel);

        // Button actions
        pullTriggerButton.addActionListener(e -> {
            if (!gameOn) {
                gameLog.append("Game is already over. Start a new game to play again.\n");
                return;
            }

            if (currentChamber == bulletPosition) {
                gameLog.append("BANG! You lose, " + playerName + "\n");            
                leaderboard.recordLoss();
                gameLog.append(leaderboard.getLeaderboard());
                gameOn = false;
                pullTriggerButton.setEnabled(false);
                playAgainButton.setEnabled(true);
            } else {
                gameLog.append("Click! You're safe, " + playerName + "\n");
                leaderboard.recordSafe();
                currentChamber = (currentChamber % 6) + 1;
            }
        });

        playAgainButton.addActionListener(e -> resetGame(random, gameLog, pullTriggerButton, playAgainButton, imageLabel));
        
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon(RussianRoulette.class.getResource("/image/pretrigger.jpg")));
        lblNewLabel.setBounds(213, 310, 212, 142);
        panel.add(lblNewLabel);
    }

    private static void resetGame(Random random, JTextArea gameLog, JButton pullTriggerButton, JButton playAgainButton, JLabel imageLabel) {
        bulletPosition = random.nextInt(6) + 1;
        currentChamber = random.nextInt(6) + 1;
        gameOn = true;
        pullTriggerButton.setEnabled(true);
        playAgainButton.setEnabled(false);
        gameLog.setText("Game restarted. Revolver loaded and chamber spun.\nPress Pull Trigger to play.\n");
         
    }

    
    }