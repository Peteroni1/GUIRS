/**
 * 
 */
/**
 * 
 */
module Russian {
	requires java.desktop;
}