package Roulette;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

// Main game class for Russian Roulette
public class RussianRoulette extends JFrame {

    private static final long serialVersionUID = 1L;

    // Tracks the position of the bullet in the revolver chamber
    private static int bulletPosition;

    // Tracks the current chamber that the revolver is pointing at
    private static int currentChamber;

    // Indicates if the game is ongoing or over
    private static boolean gameOn = true;

    // Leaderboard to track game statistics like wins/losses (assumes a Leaderboard class exists)
    private static Leaderboard leaderboard = new Leaderboard();

    // Constructor for setting up the game interface
    public RussianRoulette(String playerName) {
        setTitle("Russian Roulette"); // Title of the window
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Close the application when the window is closed
        setSize(600, 600); // Window size (width x height)
        getContentPane().setLayout(null); // Absolute positioning for placing components
        setLocationRelativeTo(null); // Centers the window on the screen

        // Main panel to hold game components
        JPanel panel = new JPanel(null); // Absolute layout for free placement of components
        panel.setBounds(0, 0, 600, 600); // Covers the entire window
        getContentPane().add(panel); // Add the panel to the frame
        panel.setLayout(null);

        // Label for welcoming the player
        JLabel welcomeLabel = new JLabel("Welcome to Russian Roulette, " + playerName + "!");
        welcomeLabel.setBounds(50, 20, 500, 30); // Position and size of the label
        welcomeLabel.setFont(new Font("OCR A Extended", Font.BOLD, 16)); // Font styling
        panel.add(welcomeLabel); // Add the label to the panel

        // Text area to display game logs (e.g., events and messages)
        JTextArea gameLog = new JTextArea();
        gameLog.setFont(new Font("OCR A Extended", Font.PLAIN, 12)); // Font styling
        gameLog.setEditable(false); // Prevent user from editing the log
        JScrollPane scrollPane = new JScrollPane(gameLog); // Scrollable view for the text area
        scrollPane.setBounds(50, 60, 500, 200); // Position and size of the scroll pane
        panel.add(scrollPane); // Add the scroll pane to the panel

        // Button to "pull the trigger" in the game
        JButton pullTriggerButton = new JButton("Pull Trigger");
        pullTriggerButton.setBounds(151, 280, 120, 30); // Position and size of the button

        // Button to start a new game
        JButton playAgainButton = new JButton("Play Again");
        playAgainButton.setBounds(300, 280, 120, 30); // Position and size of the button
        playAgainButton.setEnabled(false); // Initially disabled until the current game ends
        panel.add(pullTriggerButton); // Add the trigger button to the panel
        panel.add(playAgainButton); // Add the play again button to the panel

        // Label to display dynamic images based on the game state
        JLabel imageLabel = new JLabel();
        imageLabel.setBounds(211, 363, 200, 200); // Position and size of the image label
        panel.add(imageLabel); // Add the image label to the panel

        // Random object for generating random numbers (used to simulate the revolver spinning)
        Random random = new Random();

        // Initialize or reset the game to a fresh state
        resetGame(random, gameLog, pullTriggerButton, playAgainButton, imageLabel);

        // Action listener for the "Pull Trigger" button
        pullTriggerButton.addActionListener(e -> {
            if (!gameOn) {
                gameLog.append("Game is already over. Start a new game to play again.\n");
                return; // Exit the function if the game is over
            }

            if (currentChamber == bulletPosition) {
                // Player loses if the current chamber matches the bullet position
                gameLog.append("BANG! You lose, " + playerName + "\n");
                leaderboard.recordLoss(); // Record the loss in the leaderboard
                gameLog.append(leaderboard.getLeaderboard()); // Show the updated leaderboard
                gameOn = false; // Mark the game as over
                pullTriggerButton.setEnabled(false); // Disable the trigger button
                playAgainButton.setEnabled(true); // Enable the play again button
            } else {
                // Player is safe if the current chamber does not match the bullet position
                gameLog.append("Click! You're safe, " + playerName + "\n");
                leaderboard.recordSafe(); // Record a "safe" event in the leaderboard
                currentChamber = (currentChamber % 6) + 1; // Move to the next chamber (cyclic rotation)
            }
        });

        // Action listener for the "Play Again" button
        playAgainButton.addActionListener(e -> resetGame(random, gameLog, pullTriggerButton, playAgainButton, imageLabel));

        // Pre-trigger image (placeholder for dynamic content)
        JLabel lblNewLabel = new JLabel("");
        lblNewLabel.setIcon(new ImageIcon(RussianRoulette.class.getResource("/image/pretrigger.jpg"))); // Set an image
        lblNewLabel.setBounds(213, 310, 212, 142); // Position and size of the image label
        panel.add(lblNewLabel); // Add the label to the panel
    }

    // Method to reset the game to its initial state
    private static void resetGame(Random random, JTextArea gameLog, JButton pullTriggerButton, JButton playAgainButton, JLabel imageLabel) {
        bulletPosition = random.nextInt(6) + 1; // Randomly position the bullet in one of the six chambers
        currentChamber = random.nextInt(6) + 1; // Randomly set the starting chamber
        gameOn = true; // Mark the game as active
        pullTriggerButton.setEnabled(true); // Enable the trigger button
        playAgainButton.setEnabled(false); // Disable the play again button
        gameLog.setText("Game restarted. Revolver loaded and chamber spun.\nPress Pull Trigger to play.\n"); // Reset the game log
    }
}
